import React, { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight, Star, Quote } from 'lucide-react';

const Testimonials = () => {
  const [currentIndex, setCurrentIndex] = useState(0);

  const testimonials = [
    {
      id: 1,
      name: "Jennifer Martinez",
      role: "Marketing Manager",
      image: "https://images.pexels.com/photos/4498606/pexels-photo-4498606.jpeg?auto=compress&cs=tinysrgb&w=200&h=200&fit=crop",
      rating: 5,
      quote: "FitnessGuide transformed my life! I lost 30 pounds and gained confidence I never knew I had. The trainers are incredibly supportive and the programs are perfectly structured.",
      results: "Lost 30lbs in 4 months",
      program: "Body Transformation"
    },
    {
      id: 2,
      name: "Marcus Thompson",
      role: "Software Developer",
      image: "https://images.pexels.com/photos/4498595/pexels-photo-4498595.jpeg?auto=compress&cs=tinysrgb&w=200&h=200&fit=crop",
      rating: 5,
      quote: "As someone who sits at a desk all day, I was skeptical about finding time for fitness. FitnessGuide made it possible with flexible scheduling and efficient workouts.",
      results: "Gained 15lbs muscle",
      program: "Strength Building"
    },
    {
      id: 3,
      name: "Sarah Kim",
      role: "Teacher",
      image: "https://images.pexels.com/photos/4498586/pexels-photo-4498586.jpeg?auto=compress&cs=tinysrgb&w=200&h=200&fit=crop",
      rating: 5,
      quote: "The yoga and mindfulness programs helped me manage stress and improved my flexibility dramatically. I feel more balanced in every aspect of my life.",
      results: "Reduced stress by 70%",
      program: "Yoga & Flexibility"
    },
    {
      id: 4,
      name: "David Rodriguez",
      role: "Business Owner",
      image: "https://images.pexels.com/photos/4498590/pexels-photo-4498590.jpeg?auto=compress&cs=tinysrgb&w=200&h=200&fit=crop",
      rating: 5,
      quote: "The HIIT programs are intense but incredibly effective. I've never been in better shape, and the energy boost throughout my day is amazing.",
      results: "Improved cardio by 40%",
      program: "HIIT Cardio"
    },
    {
      id: 5,
      name: "Amanda Chen",
      role: "Nurse",
      image: "https://images.pexels.com/photos/4498581/pexels-photo-4498581.jpeg?auto=compress&cs=tinysrgb&w=200&h=200&fit=crop",
      rating: 5,
      quote: "Working long shifts, I needed something that would give me energy, not drain it. The beginner program was perfect, and now I'm stronger than ever.",
      results: "Increased energy by 60%",
      program: "Beginner Basics"
    }
  ];

  const nextTestimonial = () => {
    setCurrentIndex((prevIndex) => (prevIndex + 1) % testimonials.length);
  };

  const prevTestimonial = () => {
    setCurrentIndex((prevIndex) => (prevIndex - 1 + testimonials.length) % testimonials.length);
  };

  // Auto-advance testimonials
  useEffect(() => {
    const interval = setInterval(nextTestimonial, 5000);
    return () => clearInterval(interval);
  }, []);

  return (
    <section id="testimonials" className="py-20 bg-gradient-to-br from-blue-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Success Stories
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Hear from our members who have transformed their lives through dedication and our expert guidance.
          </p>
        </div>

        {/* Main Testimonial Slider */}
        <div className="relative max-w-4xl mx-auto mb-16">
          <div className="bg-white rounded-2xl shadow-xl p-8 md:p-12 relative overflow-hidden">
            {/* Quote Icon */}
            <div className="absolute top-6 right-6 text-blue-100">
              <Quote className="h-16 w-16" />
            </div>

            {/* Current Testimonial */}
            <div className="relative z-10">
              <div className="flex flex-col md:flex-row items-center space-y-6 md:space-y-0 md:space-x-8">
                {/* User Image */}
                <div className="flex-shrink-0">
                  <img
                    src={testimonials[currentIndex].image}
                    alt={testimonials[currentIndex].name}
                    className="w-24 h-24 rounded-full object-cover border-4 border-blue-100"
                  />
                </div>

                {/* Content */}
                <div className="flex-1 text-center md:text-left">
                  {/* Rating */}
                  <div className="flex justify-center md:justify-start mb-4">
                    {[...Array(testimonials[currentIndex].rating)].map((_, i) => (
                      <Star key={i} className="h-5 w-5 fill-yellow-400 text-yellow-400" />
                    ))}
                  </div>

                  {/* Quote */}
                  <blockquote className="text-lg md:text-xl text-gray-700 mb-6 leading-relaxed italic">
                    "{testimonials[currentIndex].quote}"
                  </blockquote>

                  {/* User Info and Results */}
                  <div className="flex flex-col md:flex-row md:items-center md:justify-between">
                    <div>
                      <div className="font-bold text-gray-900 text-lg">
                        {testimonials[currentIndex].name}
                      </div>
                      <div className="text-gray-600">
                        {testimonials[currentIndex].role}
                      </div>
                    </div>
                    <div className="mt-4 md:mt-0 flex flex-col md:items-end">
                      <div className="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm font-semibold">
                        {testimonials[currentIndex].results}
                      </div>
                      <div className="text-blue-600 text-sm mt-1">
                        {testimonials[currentIndex].program}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Navigation Buttons */}
          <button
            onClick={prevTestimonial}
            className="absolute left-4 top-1/2 -translate-y-1/2 bg-white hover:bg-gray-50 p-3 rounded-full shadow-lg transition-all duration-300 z-20"
          >
            <ChevronLeft className="h-6 w-6 text-gray-600" />
          </button>
          <button
            onClick={nextTestimonial}
            className="absolute right-4 top-1/2 -translate-y-1/2 bg-white hover:bg-gray-50 p-3 rounded-full shadow-lg transition-all duration-300 z-20"
          >
            <ChevronRight className="h-6 w-6 text-gray-600" />
          </button>
        </div>

        {/* Testimonial Indicators */}
        <div className="flex justify-center space-x-2 mb-12">
          {testimonials.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentIndex(index)}
              className={`w-3 h-3 rounded-full transition-all duration-300 ${
                index === currentIndex ? 'bg-blue-600 w-8' : 'bg-gray-300'
              }`}
            />
          ))}
        </div>

        {/* Additional Testimonials Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.slice(0, 3).map((testimonial, index) => (
            <div
              key={testimonial.id}
              className="bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1"
            >
              <div className="flex items-center space-x-4 mb-4">
                <img
                  src={testimonial.image}
                  alt={testimonial.name}
                  className="w-12 h-12 rounded-full object-cover"
                />
                <div>
                  <div className="font-semibold text-gray-900">{testimonial.name}</div>
                  <div className="text-sm text-gray-600">{testimonial.role}</div>
                </div>
              </div>
              
              <div className="flex mb-3">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                ))}
              </div>
              
              <p className="text-gray-700 text-sm leading-relaxed">
                "{testimonial.quote.substring(0, 120)}..."
              </p>
              
              <div className="mt-4 pt-4 border-t border-gray-100">
                <div className="text-xs text-blue-600 font-semibold">
                  {testimonial.program}
                </div>
                <div className="text-xs text-green-600 mt-1">
                  {testimonial.results}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Bottom CTA */}
        <div className="text-center mt-12">
          <p className="text-gray-600 mb-6">
            Ready to write your own success story?
          </p>
          <button className="bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-500 hover:to-blue-400 text-white px-8 py-3 rounded-lg font-semibold transition-all duration-300 transform hover:scale-105">
            Start Your Transformation
          </button>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;