import React from 'react';
import { Clock, Users, Star, ArrowRight } from 'lucide-react';

const WorkoutPrograms = () => {
  const programs = [
    {
      id: 1,
      title: "Strength Building",
      description: "Build lean muscle and increase your overall strength with progressive overload techniques.",
      image: "https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop",
      duration: "12 weeks",
      participants: "2.3K+",
      rating: 4.9,
      difficulty: "Intermediate",
      features: ["Progressive overload", "Compound movements", "Nutrition guide"]
    },
    {
      id: 2,
      title: "HIIT Cardio",
      description: "High-intensity interval training to boost your metabolism and burn calories efficiently.",
      image: "https://images.pexels.com/photos/863988/pexels-photo-863988.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop",
      duration: "8 weeks",
      participants: "3.1K+",
      rating: 4.8,
      difficulty: "Advanced",
      features: ["Fat burning", "Metabolic boost", "Quick workouts"]
    },
    {
      id: 3,
      title: "Yoga & Flexibility",
      description: "Improve your flexibility, balance, and mental well-being with guided yoga sessions.",
      image: "https://images.pexels.com/photos/3822906/pexels-photo-3822906.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop",
      duration: "Ongoing",
      participants: "4.2K+",
      rating: 4.9,
      difficulty: "All Levels",
      features: ["Stress relief", "Flexibility", "Mindfulness"]
    },
    {
      id: 4,
      title: "Beginner Basics",
      description: "Perfect for fitness newcomers. Learn proper form and build a strong foundation.",
      image: "https://images.pexels.com/photos/1552106/pexels-photo-1552106.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop",
      duration: "6 weeks",
      participants: "5.8K+",
      rating: 4.9,
      difficulty: "Beginner",
      features: ["Proper form", "Basic movements", "Confidence building"]
    },
    {
      id: 5,
      title: "Athletic Performance",
      description: "Sport-specific training to enhance your athletic performance and prevent injuries.",
      image: "https://images.pexels.com/photos/1552252/pexels-photo-1552252.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop",
      duration: "16 weeks",
      participants: "1.8K+",
      rating: 4.8,
      difficulty: "Advanced",
      features: ["Sport-specific", "Injury prevention", "Performance metrics"]
    },
    {
      id: 6,
      title: "Body Transformation",
      description: "Complete body transformation program combining strength, cardio, and nutrition.",
      image: "https://images.pexels.com/photos/1552103/pexels-photo-1552103.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop",
      duration: "20 weeks",
      participants: "2.9K+",
      rating: 4.9,
      difficulty: "Intermediate",
      features: ["Full transformation", "Meal plans", "Progress tracking"]
    }
  ];

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'Beginner': return 'text-green-600 bg-green-100';
      case 'Intermediate': return 'text-yellow-600 bg-yellow-100';
      case 'Advanced': return 'text-red-600 bg-red-100';
      default: return 'text-blue-600 bg-blue-100';
    }
  };

  return (
    <section id="programs" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Workout Programs
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Choose from our scientifically designed workout programs tailored to your fitness goals and experience level.
          </p>
        </div>

        {/* Programs Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {programs.map((program) => (
            <div
              key={program.id}
              className="group bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 overflow-hidden"
            >
              {/* Image */}
              <div className="relative overflow-hidden">
                <img
                  src={program.image}
                  alt={program.title}
                  className="w-full h-48 object-cover transition-transform duration-300 group-hover:scale-110"
                />
                <div className="absolute top-4 right-4">
                  <span className={`px-3 py-1 text-sm font-medium rounded-full ${getDifficultyColor(program.difficulty)}`}>
                    {program.difficulty}
                  </span>
                </div>
              </div>

              {/* Content */}
              <div className="p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-2">{program.title}</h3>
                <p className="text-gray-600 mb-4 text-sm leading-relaxed">{program.description}</p>

                {/* Stats */}
                <div className="flex items-center justify-between mb-4 text-sm text-gray-500">
                  <div className="flex items-center space-x-1">
                    <Clock className="h-4 w-4" />
                    <span>{program.duration}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Users className="h-4 w-4" />
                    <span>{program.participants}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                    <span>{program.rating}</span>
                  </div>
                </div>

                {/* Features */}
                <div className="mb-4">
                  <div className="flex flex-wrap gap-2">
                    {program.features.map((feature, index) => (
                      <span
                        key={index}
                        className="px-2 py-1 text-xs bg-blue-50 text-blue-600 rounded-md"
                      >
                        {feature}
                      </span>
                    ))}
                  </div>
                </div>

                {/* CTA Button */}
                <button className="group/btn w-full bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-500 hover:to-blue-400 text-white py-3 px-4 rounded-lg font-semibold transition-all duration-300 flex items-center justify-center space-x-2">
                  <span>Start Program</span>
                  <ArrowRight className="h-4 w-4 transition-transform group-hover/btn:translate-x-1" />
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Bottom CTA */}
        <div className="text-center mt-12">
          <p className="text-gray-600 mb-6">
            Can't find the right program? We'll create a custom plan just for you.
          </p>
          <button className="bg-orange-500 hover:bg-orange-600 text-white px-8 py-3 rounded-lg font-semibold transition-colors duration-300">
            Get Custom Program
          </button>
        </div>
      </div>
    </section>
  );
};

export default WorkoutPrograms;