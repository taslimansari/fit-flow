import React from 'react';
import { Star, Award, Users, Instagram, Twitter, Linkedin } from 'lucide-react';

const TrainerProfiles = () => {
  const trainers = [
    {
      id: 1,
      name: "Sarah Johnson",
      specialty: "Strength Training & Nutrition",
      image: "https://images.pexels.com/photos/4498606/pexels-photo-4498606.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop",
      rating: 4.9,
      experience: "8 years",
      clients: "500+",
      certifications: ["ACSM-CPT", "Precision Nutrition"],
      bio: "Specializes in helping busy professionals build strength and develop sustainable nutrition habits.",
      achievements: ["Former Olympic athlete", "Published fitness author"],
      social: {
        instagram: "#",
        twitter: "#",
        linkedin: "#"
      }
    },
    {
      id: 2,
      name: "Mike Chen",
      specialty: "HIIT & Functional Training",
      image: "https://images.pexels.com/photos/4498595/pexels-photo-4498595.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop",
      rating: 4.8,
      experience: "6 years",
      clients: "350+",
      certifications: ["NASM-CPT", "FMS Level 2"],
      bio: "Expert in high-intensity training and functional movement patterns for real-world strength.",
      achievements: ["CrossFit Games qualifier", "Mobility specialist"],
      social: {
        instagram: "#",
        twitter: "#",
        linkedin: "#"
      }
    },
    {
      id: 3,
      name: "Emma Rodriguez",
      specialty: "Yoga & Mind-Body Connection",
      image: "https://images.pexels.com/photos/4498586/pexels-photo-4498586.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop",
      rating: 5.0,
      experience: "10 years",
      clients: "800+",
      certifications: ["RYT-500", "Meditation Teacher"],
      bio: "Combines traditional yoga with modern fitness science to help clients find balance and strength.",
      achievements: ["International yoga instructor", "Wellness retreat leader"],
      social: {
        instagram: "#",
        twitter: "#",
        linkedin: "#"
      }
    },
    {
      id: 4,
      name: "David Thompson",
      specialty: "Sports Performance & Recovery",
      image: "https://images.pexels.com/photos/4498590/pexels-photo-4498590.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop",
      rating: 4.9,
      experience: "12 years",
      clients: "600+",
      certifications: ["CSCS", "Sports Massage Therapist"],
      bio: "Former professional athlete turned trainer, specializing in performance optimization and injury prevention.",
      achievements: ["Professional athlete coach", "Sports science researcher"],
      social: {
        instagram: "#",
        twitter: "#",
        linkedin: "#"
      }
    },
    {
      id: 5,
      name: "Lisa Park",
      specialty: "Weight Loss & Lifestyle Change",
      image: "https://images.pexels.com/photos/4498581/pexels-photo-4498581.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop",
      rating: 4.9,
      experience: "7 years",
      clients: "450+",
      certifications: ["ACE-CPT", "Behavior Change Specialist"],
      bio: "Helps clients achieve sustainable weight loss through balanced fitness routines and lifestyle modifications.",
      achievements: ["Transformation specialist", "Health coach certification"],
      social: {
        instagram: "#",
        twitter: "#",
        linkedin: "#"
      }
    },
    {
      id: 6,
      name: "Alex Morgan",
      specialty: "Bodybuilding & Physique Training",
      image: "https://images.pexels.com/photos/4498594/pexels-photo-4498594.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop",
      rating: 4.8,
      experience: "9 years",
      clients: "300+",
      certifications: ["IFBB Pro Coach", "Exercise Physiologist"],
      bio: "Competitive bodybuilder and coach specializing in physique development and contest preparation.",
      achievements: ["IFBB Pro bodybuilder", "Contest prep specialist"],
      social: {
        instagram: "#",
        twitter: "#",
        linkedin: "#"
      }
    }
  ];

  return (
    <section id="trainers" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            Meet Our Expert Trainers
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Our certified fitness professionals are here to guide you on your journey to better health and fitness.
          </p>
        </div>

        {/* Trainers Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {trainers.map((trainer) => (
            <div
              key={trainer.id}
              className="group bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 overflow-hidden"
            >
              {/* Image and Rating */}
              <div className="relative">
                <img
                  src={trainer.image}
                  alt={trainer.name}
                  className="w-full h-64 object-cover transition-transform duration-300 group-hover:scale-105"
                />
                <div className="absolute top-4 left-4 bg-white/90 backdrop-blur-sm rounded-lg px-3 py-1">
                  <div className="flex items-center space-x-1">
                    <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                    <span className="font-semibold text-gray-800">{trainer.rating}</span>
                  </div>
                </div>
              </div>

              {/* Content */}
              <div className="p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-1">{trainer.name}</h3>
                <p className="text-blue-600 font-medium mb-4">{trainer.specialty}</p>
                
                <p className="text-gray-600 text-sm mb-4 leading-relaxed">{trainer.bio}</p>

                {/* Stats */}
                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div className="text-center p-3 bg-blue-50 rounded-lg">
                    <div className="flex items-center justify-center space-x-1 mb-1">
                      <Award className="h-4 w-4 text-blue-600" />
                      <span className="font-semibold text-gray-800">{trainer.experience}</span>
                    </div>
                    <p className="text-xs text-gray-600">Experience</p>
                  </div>
                  <div className="text-center p-3 bg-green-50 rounded-lg">
                    <div className="flex items-center justify-center space-x-1 mb-1">
                      <Users className="h-4 w-4 text-green-600" />
                      <span className="font-semibold text-gray-800">{trainer.clients}</span>
                    </div>
                    <p className="text-xs text-gray-600">Clients Trained</p>
                  </div>
                </div>

                {/* Certifications */}
                <div className="mb-4">
                  <p className="text-xs text-gray-500 mb-2">Certifications:</p>
                  <div className="flex flex-wrap gap-1">
                    {trainer.certifications.map((cert, index) => (
                      <span
                        key={index}
                        className="px-2 py-1 text-xs bg-orange-100 text-orange-700 rounded-md"
                      >
                        {cert}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Achievements */}
                <div className="mb-6">
                  <p className="text-xs text-gray-500 mb-2">Key Achievements:</p>
                  <ul className="text-xs text-gray-600 space-y-1">
                    {trainer.achievements.map((achievement, index) => (
                      <li key={index} className="flex items-start">
                        <span className="w-1 h-1 bg-blue-500 rounded-full mt-2 mr-2 flex-shrink-0"></span>
                        {achievement}
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Social Links and CTA */}
                <div className="flex items-center justify-between">
                  <div className="flex space-x-3">
                    <a
                      href={trainer.social.instagram}
                      className="text-gray-400 hover:text-pink-500 transition-colors"
                    >
                      <Instagram className="h-5 w-5" />
                    </a>
                    <a
                      href={trainer.social.twitter}
                      className="text-gray-400 hover:text-blue-500 transition-colors"
                    >
                      <Twitter className="h-5 w-5" />
                    </a>
                    <a
                      href={trainer.social.linkedin}
                      className="text-gray-400 hover:text-blue-700 transition-colors"
                    >
                      <Linkedin className="h-5 w-5" />
                    </a>
                  </div>
                  <button className="bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-500 hover:to-blue-400 text-white px-4 py-2 rounded-lg text-sm font-semibold transition-all duration-300">
                    Book Session
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Bottom CTA */}
        <div className="text-center mt-12">
          <p className="text-gray-600 mb-6">
            Ready to work with one of our expert trainers?
          </p>
          <button className="bg-orange-500 hover:bg-orange-600 text-white px-8 py-3 rounded-lg font-semibold transition-colors duration-300">
            Schedule Free Consultation
          </button>
        </div>
      </div>
    </section>
  );
};

export default TrainerProfiles;