import React, { useState, useEffect } from 'react';
import { Menu, X, Dumbbell, User, LogOut } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

const Navigation = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const { user, signOut, openAuthModal, setAuthMode } = useAuth();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (sectionId: string) => {
    document.getElementById(sectionId)?.scrollIntoView({ behavior: 'smooth' });
    setIsOpen(false);
  };

  const handleAuth = (mode: 'signin' | 'signup') => {
    setAuthMode(mode);
    openAuthModal();
  };

  return (
    <nav className={`fixed w-full z-50 transition-all duration-300 ${
      isScrolled ? 'bg-white/95 backdrop-blur-md shadow-lg' : 'bg-transparent'
    }`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <div className="flex items-center space-x-2">
            <Dumbbell className="h-8 w-8 text-blue-600" />
            <span className={`font-bold text-xl ${
              isScrolled ? 'text-gray-800' : 'text-white'
            }`}>
              FitnessGuide
            </span>
          </div>

          {/* Desktop Menu */}
          <div className="hidden md:block">
            <div className="ml-10 flex items-baseline space-x-4">
              <button
                onClick={() => scrollToSection('home')}
                className={`px-3 py-2 text-sm font-medium transition-colors ${
                  isScrolled 
                    ? 'text-gray-800 hover:text-blue-600' 
                    : 'text-white hover:text-blue-300'
                }`}
              >
                Home
              </button>
              <button
                onClick={() => scrollToSection('programs')}
                className={`px-3 py-2 text-sm font-medium transition-colors ${
                  isScrolled 
                    ? 'text-gray-800 hover:text-blue-600' 
                    : 'text-white hover:text-blue-300'
                }`}
              >
                Programs
              </button>
              <button
                onClick={() => scrollToSection('trainers')}
                className={`px-3 py-2 text-sm font-medium transition-colors ${
                  isScrolled 
                    ? 'text-gray-800 hover:text-blue-600' 
                    : 'text-white hover:text-blue-300'
                }`}
              >
                Trainers
              </button>
              <button
                onClick={() => scrollToSection('testimonials')}
                className={`px-3 py-2 text-sm font-medium transition-colors ${
                  isScrolled 
                    ? 'text-gray-800 hover:text-blue-600' 
                    : 'text-white hover:text-blue-300'
                }`}
              >
                Reviews
              </button>
              <button
                onClick={() => scrollToSection('contact')}
                className={`px-3 py-2 text-sm font-medium transition-colors ${
                  isScrolled 
                    ? 'text-gray-800 hover:text-blue-600' 
                    : 'text-white hover:text-blue-300'
                }`}
              >
                Contact
              </button>
            </div>
          </div>

          {/* Auth Buttons */}
          <div className="hidden md:flex items-center space-x-4">
            {user ? (
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-2">
                  <User className="h-5 w-5 text-blue-600" />
                  <span className={`text-sm ${
                    isScrolled ? 'text-gray-800' : 'text-white'
                  }`}>
                    {user.email?.split('@')[0]}
                  </span>
                </div>
                <button
                  onClick={signOut}
                  className="flex items-center space-x-2 px-4 py-2 text-sm font-medium text-white bg-red-600 rounded-lg hover:bg-red-700 transition-colors"
                >
                  <LogOut className="h-4 w-4" />
                  <span>Logout</span>
                </button>
              </div>
            ) : (
              <div className="flex items-center space-x-4">
                <button
                  onClick={() => handleAuth('signin')}
                  className={`px-4 py-2 text-sm font-medium rounded-lg transition-colors ${
                    isScrolled
                      ? 'text-gray-800 hover:bg-gray-100'
                      : 'text-white hover:bg-white/20'
                  }`}
                >
                  Login
                </button>
                <button
                  onClick={() => handleAuth('signup')}
                  className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700 transition-colors"
                >
                  Sign Up
                </button>
              </div>
            )}
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className={`p-2 rounded-md ${
                isScrolled ? 'text-gray-800' : 'text-white'
              }`}
            >
              {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="md:hidden">
          <div className="px-2 pt-2 pb-3 space-y-1 bg-white shadow-lg">
            <button
              onClick={() => scrollToSection('home')}
              className="block px-3 py-2 text-gray-800 hover:text-blue-600"
            >
              Home
            </button>
            <button
              onClick={() => scrollToSection('programs')}
              className="block px-3 py-2 text-gray-800 hover:text-blue-600"
            >
              Programs
            </button>
            <button
              onClick={() => scrollToSection('trainers')}
              className="block px-3 py-2 text-gray-800 hover:text-blue-600"
            >
              Trainers
            </button>
            <button
              onClick={() => scrollToSection('testimonials')}
              className="block px-3 py-2 text-gray-800 hover:text-blue-600"
            >
              Reviews
            </button>
            <button
              onClick={() => scrollToSection('contact')}
              className="block px-3 py-2 text-gray-800 hover:text-blue-600"
            >
              Contact
            </button>
            
            <div className="border-t pt-4">
              {user ? (
                <div className="space-y-2">
                  <div className="flex items-center space-x-2 px-3 py-2">
                    <User className="h-5 w-5 text-blue-600" />
                    <span className="text-gray-800">{user.email?.split('@')[0]}</span>
                  </div>
                  <button
                    onClick={signOut}
                    className="flex items-center space-x-2 px-3 py-2 text-red-600 hover:bg-red-50 w-full"
                  >
                    <LogOut className="h-4 w-4" />
                    <span>Logout</span>
                  </button>
                </div>
              ) : (
                <div className="space-y-2">
                  <button
                    onClick={() => handleAuth('signin')}
                    className="block px-3 py-2 text-gray-800 hover:bg-gray-100 w-full text-left"
                  >
                    Login
                  </button>
                  <button
                    onClick={() => handleAuth('signup')}
                    className="block px-3 py-2 text-white bg-blue-600 hover:bg-blue-700 rounded mx-3"
                  >
                    Sign Up
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navigation;