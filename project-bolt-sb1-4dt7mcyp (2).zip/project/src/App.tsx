import React from 'react';
import Navigation from './components/Navigation';
import Hero from './components/Hero';
import WorkoutPrograms from './components/WorkoutPrograms';
import TrainerProfiles from './components/TrainerProfiles';
import Testimonials from './components/Testimonials';
import Contact from './components/Contact';
import Footer from './components/Footer';
import AuthModal from './components/AuthModal';
import { AuthProvider } from './contexts/AuthContext';

function App() {
  return (
    <AuthProvider>
      <div className="min-h-screen bg-gray-50">
        <Navigation />
        <Hero />
        <WorkoutPrograms />
        <TrainerProfiles />
        <Testimonials />
        <Contact />
        <Footer />
        <AuthModal />
      </div>
    </AuthProvider>
  );
}

export default App;